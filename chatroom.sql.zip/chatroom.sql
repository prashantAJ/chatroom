-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 08, 2020 at 05:38 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `chatroom`
--

-- --------------------------------------------------------

--
-- Table structure for table `msgs`
--

CREATE TABLE IF NOT EXISTS `msgs` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `msg` text NOT NULL,
  `room` varchar(50) NOT NULL,
  `ip` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `msgs`
--

INSERT INTO `msgs` (`sno`, `msg`, `room`, `ip`, `time`) VALUES
(11, 'hello', 'room4', 1270, '2020-06-08 02:23:36'),
(10, 'Hello', 'room4', 1270, '2020-06-08 02:22:46'),
(5, 'This is me', 'room4', 1270, '2020-06-07 22:00:09'),
(6, 'Submit testing', 'room4', 1270, '2020-06-07 22:02:27'),
(7, 'Submit testing', 'room4', 1270, '2020-06-07 22:02:31'),
(8, 'Testing msg field', 'room4', 1270, '2020-06-07 22:05:39'),
(9, 'Enter ', 'room4', 1270, '2020-06-07 22:06:30'),
(12, 'hi', 'room4', 1270, '2020-06-08 02:23:43'),
(13, '1', 'room4', 1270, '2020-06-08 02:24:01'),
(14, '2', 'room4', 1270, '2020-06-08 02:24:09'),
(15, 'hello', 'room4', 1270, '2020-06-08 02:24:18'),
(16, 'Bhai kaisa h?', 'room4', 1270, '2020-06-08 02:25:38'),
(17, 'Badiya hu bhai', 'room4', 1270, '2020-06-08 02:26:00'),
(19, 'hrgnv', 'room4', 1270, '2020-06-08 02:38:36'),
(20, 'dg', 'room4', 1270, '2020-06-08 02:40:38'),
(22, 'Chat with me', 'room1', 1270, '2020-06-08 02:53:55'),
(23, 'room4 1', 'room4', 1270, '2020-06-08 18:25:49'),
(24, 'room1 2', 'room1', 1270, '2020-06-08 18:26:10'),
(25, 'room4 3', 'room4', 1270, '2020-06-08 18:26:22'),
(26, 'room1 4', 'room1', 1270, '2020-06-08 18:26:32'),
(27, 'Hello, my name is room4', 'room4', 1270, '2020-06-08 18:49:33');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE IF NOT EXISTS `room` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `roomname` varchar(50) NOT NULL,
  `stime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`sno`, `roomname`, `stime`) VALUES
(1, 'room', '2020-06-07 15:49:35'),
(2, 'room1', '2020-06-07 19:02:04'),
(3, 'room2', '2020-06-07 19:02:45'),
(4, 'room3', '2020-06-07 20:09:08'),
(5, 'room4', '2020-06-07 21:42:11'),
(6, 'room5', '2020-06-08 02:10:08'),
(9, 'Aman', '2020-06-08 21:19:46'),
(8, 'Prashant Arjariya', '2020-06-08 21:15:11');
